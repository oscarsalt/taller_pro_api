<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Usuario.php';

class AuthController {

    private function getDB(){
        $database = new Database();
        return $database->connect();
    }

    public function register(){

        $data = json_decode(file_get_contents("php://input"), true);

if(!$data){
    echo json_encode([
        "error"=>"Datos JSON no enviados correctamente"
    ]);
    return;
}

        $db = $this->getDB();
        $usuario = new Usuario($db);

        $usuario->createUsuario($data);

        echo json_encode([
            "message"=>"Usuario creado"
        ]);
    }

    public function login(){

        $data = json_decode(file_get_contents("php://input"),true);

        $db = $this->getDB();
        $usuario = new Usuario($db);

        $user = $usuario->getByEmail($data["email"]);

        if($user && password_verify($data["password"],$user["password"])){

            echo json_encode([
                "message"=>"Login correcto",
                "user"=>$user
            ]);

        }else{

            echo json_encode([
                "message"=>"Credenciales incorrectas"
            ]);

        }
    }

}