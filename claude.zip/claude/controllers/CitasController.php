<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Cita.php';

class CitasController {

    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->connect();
    }

    // ======================
    // LISTAR
    // ======================
    public function getCitas() {

        $cita = new Cita($this->conn);
        echo json_encode($cita->getCitas());
    }

    // ======================
    // CREAR
    // ======================
    public function createCita() {

        $data = json_decode(file_get_contents("php://input"), true);

        $cita = new Cita($this->conn);
        $cita->createCita($data);

        echo json_encode(["message" => "Cita creada"]);
    }

    // ======================
    // ELIMINAR
    // ======================
    public function deleteCita($id) {

        $cita = new Cita($this->conn);
        $cita->deleteCita($id);

        echo json_encode(["message" => "Cita eliminada"]);
    }

    // ======================
    // ACTUALIZAR ESTADO 🔥
    // ======================
    public function updateEstado($id) {

        $data = json_decode(file_get_contents("php://input"), true);

        $query = "UPDATE citas SET estado = :estado WHERE id_cita = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->execute([
            "estado" => $data["estado"],
            "id" => $id
        ]);

        echo json_encode(["message" => "Estado actualizado"]);
    }

public function subirPresupuesto($id){

    if(!isset($_FILES["file"])){
        echo json_encode(["error"=>"No se envió archivo"]);
        return;
    }

    $file = $_FILES["file"];

    $nombre = time() . "_" . $file["name"];

    $ruta = __DIR__ . "/../uploads/" . $nombre;
    $rutaBD = "uploads/" . $nombre;

    if(!file_exists(__DIR__ . "/../uploads")){
        mkdir(__DIR__ . "/../uploads",0777,true);
    }

    if(move_uploaded_file($file["tmp_name"], $ruta)){

        $db = $this->getDB();

        $query = "UPDATE citas SET presupuesto = :ruta WHERE id_cita = :id";

        $stmt = $db->prepare($query);
        $stmt->execute([
            "ruta"=>$rutaBD,
            "id"=>$id
        ]);

        echo json_encode(["message"=>"PDF subido"]);

    } else {
        echo json_encode(["error"=>"Error al mover archivo"]);
    }
}
}

