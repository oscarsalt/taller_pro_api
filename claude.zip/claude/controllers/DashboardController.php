<?php

require_once __DIR__ . '/../config/database.php';

class DashboardController {

    private function getDB(){
        $database = new Database();
        return $database->connect();
    }

    public function estadisticas(){

        $db = $this->getDB();

        $data = [];

        // Total clientes
        $stmt = $db->query("SELECT COUNT(*) as total FROM clientes");
        $data["clientes"] = $stmt->fetch(PDO::FETCH_ASSOC)["total"];

        // Total vehiculos
        $stmt = $db->query("SELECT COUNT(*) as total FROM vehiculos");
        $data["vehiculos"] = $stmt->fetch(PDO::FETCH_ASSOC)["total"];

        // Total citas
        $stmt = $db->query("SELECT COUNT(*) as total FROM citas");
        $data["citas"] = $stmt->fetch(PDO::FETCH_ASSOC)["total"];

        // Citas de hoy
        $stmt = $db->query("SELECT COUNT(*) as total FROM citas WHERE fecha = CURDATE()");
        $data["citas_hoy"] = $stmt->fetch(PDO::FETCH_ASSOC)["total"];

        // Ingresos
        $stmt = $db->query("SELECT IFNULL(SUM(precio),0) as total FROM reparaciones");
        $data["ingresos"] = $stmt->fetch(PDO::FETCH_ASSOC)["total"];

        echo json_encode($data);
    }
}