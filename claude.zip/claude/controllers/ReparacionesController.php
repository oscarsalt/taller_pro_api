<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Reparacion.php';

class ReparacionesController {

    private function getDB(){

        $database = new Database();
        return $database->connect();
    }

    public function getReparaciones(){

        $db = $this->getDB();
        $rep = new Reparacion($db);

        $stmt = $rep->getReparaciones();

        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    public function getReparacion($id){

        $db = $this->getDB();
        $rep = new Reparacion($db);

        echo json_encode($rep->getReparacion($id));
    }

    public function createReparacion(){

        $data = json_decode(file_get_contents("php://input"),true);

        if(!$data){
            $data = $_POST;
        }

        $db = $this->getDB();
        $rep = new Reparacion($db);

        $rep->createReparacion($data);

        echo json_encode(["message"=>"Reparacion creada"]);
    }

    public function updateReparacion($id){

        $data = json_decode(file_get_contents("php://input"),true);

        $db = $this->getDB();
        $rep = new Reparacion($db);

        $rep->updateReparacion($id,$data);

        echo json_encode(["message"=>"Reparacion actualizada"]);
    }

    public function deleteReparacion($id){

        $db = $this->getDB();
        $rep = new Reparacion($db);

        $rep->deleteReparacion($id);

        echo json_encode(["message"=>"Reparacion eliminada"]);
    }

}