<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Vehiculo.php';

class VehiculosController {

    private function getDB(){

        $database = new Database();
        return $database->connect();
    }
/*
    public function getVehiculos(){

        $db = $this->getDB();
        $vehiculo = new Vehiculo($db);

        $stmt = $vehiculo->getVehiculos();

        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
*/
public function getVehiculos(){

    $db = $this->getDB();
    $vehiculo = new Vehiculo($db);

    echo json_encode($vehiculo->getVehiculos());
}
    public function getVehiculo($id){

        $db = $this->getDB();
        $vehiculo = new Vehiculo($db);

        echo json_encode($vehiculo->getVehiculo($id));
    }

    public function createVehiculo(){

        $data = json_decode(file_get_contents("php://input"),true);

        if(!$data){
            $data = $_POST;
        }

        $db = $this->getDB();
        $vehiculo = new Vehiculo($db);

        $vehiculo->createVehiculo($data);

        echo json_encode(["message"=>"Vehiculo creado"]);
    }

    public function deleteVehiculo($id){

        $db = $this->getDB();
        $vehiculo = new Vehiculo($db);

        $vehiculo->deleteVehiculo($id);

        echo json_encode(["message"=>"Vehiculo eliminado"]);
    }

}