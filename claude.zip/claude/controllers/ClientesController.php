<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Cliente.php';

class ClientesController {

    private function getDB(){
        $database = new Database();
        return $database->connect();
    }

    public function getClientes(){

        $db = $this->getDB();
        $cliente = new Cliente($db);

        $stmt = $cliente->getClientes();

        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    public function getCliente($id){

        $db = $this->getDB();
        $cliente = new Cliente($db);

        echo json_encode($cliente->getClienteById($id));
    }

    public function createCliente(){

        $data = json_decode(file_get_contents("php://input"),true);

        $db = $this->getDB();
        $cliente = new Cliente($db);

        $cliente->createCliente($data);

        echo json_encode(["message"=>"Cliente creado"]);
    }

    public function updateCliente($id){

        $data = json_decode(file_get_contents("php://input"),true);

        $db = $this->getDB();
        $cliente = new Cliente($db);

        $cliente->updateCliente($id,$data);

        echo json_encode(["message"=>"Cliente actualizado"]);
    }

    public function deleteCliente($id){

        $db = $this->getDB();
        $cliente = new Cliente($db);

        $cliente->deleteCliente($id);

        echo json_encode(["message"=>"Cliente eliminado"]);
    }

}