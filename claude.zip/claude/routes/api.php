<?php

require_once __DIR__ . '/../controllers/ClientesController.php';
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/VehiculosController.php';
require_once __DIR__ . '/../controllers/CitasController.php';
require_once __DIR__ . '/../controllers/ReparacionesController.php';
require_once __DIR__ . '/../controllers/DashboardController.php';

$request = $_SERVER['REQUEST_URI'];
$method = $_SERVER['REQUEST_METHOD'];

/* quitar query params */
$request = explode("?", $request)[0];

/* separar la url */
$segments = explode("/", trim($request,"/"));

/* buscar si hay id */
$id = null;
if(isset($segments[count($segments)-1]) && is_numeric($segments[count($segments)-1])){
    $id = $segments[count($segments)-1];
}

/* controladores */
$clientes = new ClientesController();
$auth = new AuthController();
$vehiculos = new VehiculosController();
$citas = new CitasController();
$reparaciones = new ReparacionesController();
$dashboard = new DashboardController();

/* =======================
   CLIENTES
======================= */

if(str_contains($request,"clientes")){

    if($method === "GET" && !$id){
        $clientes->getClientes();
        return;
    }

    if($method === "GET" && $id){
        $clientes->getCliente($id);
        return;
    }

    if($method === "POST"){
        $clientes->createCliente();
        return;
    }

    if($method === "PUT" && $id){
        $clientes->updateCliente($id);
        return;
    }

    if($method === "DELETE" && $id){
        $clientes->deleteCliente($id);
        return;
    }

}

/* =======================
   AUTH
======================= */

if(str_contains($request,"register") && $method === "POST"){
    $auth->register();
    return;
}

if(str_contains($request,"login") && $method === "POST"){
    $auth->login();
    return;
}

/* =======================
   VEHICULOS
======================= */

if(str_contains($request,"vehiculos")){

    if($method=="GET" && !$id){
        $vehiculos->getVehiculos();
        return;
    }

    if($method=="GET" && $id){
        $vehiculos->getVehiculo($id);
        return;
    }

    if($method=="POST"){
        $vehiculos->createVehiculo();
        return;
    }

    if($method=="DELETE" && $id){
        $vehiculos->deleteVehiculo($id);
        return;
    }

}

/* =======================
   CITAS
======================= */

if(str_contains($request,"citas")){

if($method=="POST" && str_contains($request,"upload") && $id){
    $citas->subirPresupuesto($id);
    return;
}

    // 🔥 ACTUALIZAR ESTADO (PRIMERO)
    if($method=="POST" && str_contains($request,"update") && $id){
        $citas->updateEstado($id);
        return;
    }

    // LISTAR
    if($method=="GET" && !$id){
        $citas->getCitas();
        return;
    }

    // OBTENER UNA
    if($method=="GET" && $id){
        $citas->getCita($id);
        return;
    }



    // CREAR
    if($method=="POST"){
        $citas->createCita();
        return;
    }

    // ELIMINAR
    if($method=="DELETE" && $id){
        $citas->deleteCita($id);
        return;
    }

}

/* =======================
   REPARACIONES
======================= */

if(str_contains($request,"reparaciones")){

    if($method=="GET" && !$id){
        $reparaciones->getReparaciones();
        return;
    }

    if($method=="GET" && $id){
        $reparaciones->getReparacion($id);
        return;
    }

    if($method=="POST"){
        $reparaciones->createReparacion();
        return;
    }

    if($method=="PUT" && $id){
        $reparaciones->updateReparacion($id);
        return;
    }

    if($method=="DELETE" && $id){
        $reparaciones->deleteReparacion($id);
        return;
    }

}

/* =======================
   DASHBOARD
======================= */

if(str_contains($request,"dashboard")){

    if($method=="GET"){
        $dashboard->estadisticas();
        return;
    }

}

/* =======================
   PRESUPUESTO
======================= */



/* =======================
   NO ENCONTRADO
======================= */

echo json_encode([
    "error" => "Endpoint no encontrado"
]);