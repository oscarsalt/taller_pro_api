<?php

class Vehiculo {

    private $conn;
    private $table = "vehiculos";

    public function __construct($db){
        $this->conn = $db;
    }

    // ======================
    // LISTAR VEHICULOS
    // ======================
    public function getVehiculos(){

        $query = "SELECT * FROM vehiculos";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ======================
    // OBTENER UN VEHICULO
    // ======================
    public function getVehiculo($id){

        $query = "SELECT * FROM vehiculos WHERE id_vehiculo = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->execute(["id"=>$id]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // ======================
    // CREAR VEHICULO
    // ======================
    public function createVehiculo($data){

        $query = "INSERT INTO vehiculos 
        (id_cliente, marca, modelo, matricula, anio)
        VALUES 
        (:id_cliente, :marca, :modelo, :matricula, :anio)";

        $stmt = $this->conn->prepare($query);

        return $stmt->execute([
            "id_cliente" => $data["id_cliente"],
            "marca" => $data["marca"],
            "modelo" => $data["modelo"],
            "matricula" => $data["matricula"],
            "anio" => $data["anio"]
        ]);
    }

    // ======================
    // ELIMINAR VEHICULO
    // ======================
    public function deleteVehiculo($id){

        $query = "DELETE FROM vehiculos WHERE id_vehiculo = :id";

        $stmt = $this->conn->prepare($query);

        return $stmt->execute(["id"=>$id]);
    }

}