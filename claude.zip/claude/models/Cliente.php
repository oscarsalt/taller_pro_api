<?php

class Cliente {

    private $conn;
    private $table = "clientes";

    public function __construct($db){
        $this->conn = $db;
    }

    public function getClientes(){

        $query = "SELECT * FROM " . $this->table;

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }

    public function getClienteById($id){

        $query = "SELECT * FROM " . $this->table . " WHERE id_cliente = ?";

        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function createCliente($data){

        $query = "INSERT INTO clientes (nombre, telefono, email, direccion)
                  VALUES (:nombre, :telefono, :email, :direccion)";

        $stmt = $this->conn->prepare($query);

        return $stmt->execute([
            "nombre" => $data["nombre"],
            "telefono" => $data["telefono"],
            "email" => $data["email"],
            "direccion" => $data["direccion"]
        ]);
    }

    public function updateCliente($id,$data){

        $query = "UPDATE clientes
                  SET nombre=:nombre, telefono=:telefono, email=:email, direccion=:direccion
                  WHERE id_cliente=:id";

        $stmt = $this->conn->prepare($query);

        return $stmt->execute([
            "nombre"=>$data["nombre"],
            "telefono"=>$data["telefono"],
            "email"=>$data["email"],
            "direccion"=>$data["direccion"],
            "id"=>$id
        ]);
    }

    public function deleteCliente($id){

        $query = "DELETE FROM clientes WHERE id_cliente=?";

        $stmt = $this->conn->prepare($query);

        return $stmt->execute([$id]);
    }

}