<?php

class Cita {

    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    // ======================
    // LISTAR
    // ======================
 /*   public function getCitas() {

        $query = "SELECT * FROM citas";
        $stmt = $this->conn->query($query);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }*/
public function getCitas(){

    $query = "SELECT 
                c.id_cita,
                c.fecha,
                c.hora,
                c.estado,
                c.descripcion,

                v.marca,
                v.modelo,
                v.matricula,

                cl.nombre

              FROM citas c
              JOIN vehiculos v ON c.id_vehiculo = v.id_vehiculo
              JOIN clientes cl ON c.id_cliente = cl.id_cliente";

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
    // ======================
    // CREAR
    // ======================
    public function createCita($data) {

        $query = "INSERT INTO citas 
        (id_cliente, id_vehiculo, fecha, hora, estado, descripcion)
        VALUES 
        (:id_cliente, :id_vehiculo, :fecha, :hora, :estado, :descripcion)";

        $stmt = $this->conn->prepare($query);

        $stmt->execute([
            "id_cliente" => $data["id_cliente"],
            "id_vehiculo" => $data["id_vehiculo"],
            "fecha" => $data["fecha"],
            "hora" => $data["hora"],
            "estado" => $data["estado"],
            "descripcion" => $data["descripcion"]
        ]);
    }

    // ======================
    // ELIMINAR
    // ======================
    public function deleteCita($id) {

        $query = "DELETE FROM citas WHERE id_cita = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->execute(["id" => $id]);
    }
}